document.addEventListener("DOMContentLoaded", function () {
    const modalLogin = document.getElementById("modal-login");
    const modalRegister = document.getElementById("modal-register");
    const buttonLogin = document.querySelector(".button-login-account");
    const buttonSignup = document.querySelector(".button-create-account");
    const buttonCloseModalLogin = document.querySelector("#modal-login .button-close-modal");
    const buttonCloseModalRegister = document.querySelector("#modal-register .button-close-modal");
  
    // Fungsi untuk menampilkan modal sign in
    function showModalLogin() {
      modalLogin.classList.remove("display-hidden");
    }
  
    // Fungsi untuk menampilkan modal sign up
    function showModalRegister() {
      modalRegister.classList.remove("display-hidden");
    }
  
    // Fungsi untuk menutup modal sign in
    function closeModalLogin() {
      modalLogin.classList.add("display-hidden");
    }
  
    // Fungsi untuk menutup modal sign up
    function closeModalRegister() {
      modalRegister.classList.add("display-hidden");
    }
  
    // Event listener untuk tombol "Sign in" dan "Sign up"
    buttonLogin.addEventListener("click", showModalLogin);
    buttonSignup.addEventListener("click", showModalRegister);
  
    // Event listener untuk tombol close di dalam modal
    buttonCloseModalLogin.addEventListener("click", closeModalLogin);
    buttonCloseModalRegister.addEventListener("click", closeModalRegister);
  
    // Event listener untuk menutup modal saat klik di luar modal
    window.addEventListener("click", function (event) {
      if (event.target === modalLogin) {
        closeModalLogin();
      }
      if (event.target === modalRegister) {
        closeModalRegister();
      }
    });
  });
  